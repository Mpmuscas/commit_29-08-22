/* import logo from './logo.svg'; */
import './App.css';

import ButtonComponent from './components/ButtonComponent';
import ImageComponent from './components/ImageComponent';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        {/* <img src={logo} className="App-logo" alt="logo" /> */}
        <ImageComponent src="\logo192.png" alt="logo" />

        <ButtonComponent title="CLICCAMI" color="green" />

      </header>
    </div>
  );
}

export default App;

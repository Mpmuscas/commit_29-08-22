

const ButtonComponent = (props) => 

 <button style={
    {backgroundColor: 'green',
     color:'white',
      borderColor: 'white',
       padding: '0.7em',
        marginTop: '1em'}
    }
    
    > {props.title} </button>
       



export default ButtonComponent